package com;

import modelo.MethodsHandle;
import ThriftGenerate.Methods;
import org.apache.thrift.server.TServer;
import org.apache.thrift.server.TThreadPoolServer;
import org.apache.thrift.transport.TServerSocket;
import org.apache.thrift.transport.TServerTransport;


public class Main {
	
	public static void main(String[] args) {
		try {

			MethodsHandle handler = new MethodsHandle();
			Methods.Processor processor = new Methods.Processor(handler);
			TServerTransport serverTransport = new TServerSocket(1414);
			TServer server = new TThreadPoolServer(new TThreadPoolServer.Args(serverTransport).processor(processor));
			//TServer server = new TSimpleServer(new Args(serverTransport).processor(processor));

			// server = new TThreadPoolServer(new Args(serverTransport).processor(processor));

			System.out.println("O servidor esta sendo iniciado...");
			server.serve();
		} catch(Exception x) {
			x.printStackTrace();
		}
		System.out.println("Terminado...");
	}
}
