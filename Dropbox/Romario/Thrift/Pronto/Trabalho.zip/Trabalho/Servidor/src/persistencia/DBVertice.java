/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

/**
 *
 * @author dcosta
 */

import jdbm.RecordManager;
import jdbm.RecordManagerFactory;
import jdbm.helper.FastIterator;
import jdbm.htree.HTree;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import modelo.entidades.DadosVertex;

public class DBVertice {

    private final RecordManager manager;
    private final HTree hashtable;
    private FastIterator iterator;

    public DBVertice() throws IOException {
        manager = RecordManagerFactory.createRecordManager("DBVertice", new Properties());
        long recid = manager.getNamedObject("vertex");
        if (recid != 0) {
            System.out.println("Carregando banco de dados de vertices...");
            hashtable = HTree.load(manager, recid);
        } else {
            System.out.println("Criando novo vertice no bando de dados...");
            hashtable = HTree.createInstance(manager);
            manager.setNamedObject("vertex", hashtable.getRecid());
        }
    }

    public synchronized void addVertice(DadosVertex data) throws IOException {
        String id = Integer.toString(data.getIdVertex());
        hashtable.put(id, data);
        manager.commit();
    }

    public synchronized void removeVertice(int idVertex) throws IOException {
        String id = Integer.toString(idVertex);
        hashtable.remove(id);
        manager.commit();
    }

    public synchronized DadosVertex deletaVertice(int idVertex) throws IOException {
        String id = Integer.toString(idVertex);
        return (DadosVertex) hashtable.get(id);
    }

    public List<String> mostraVertice() throws IOException {
        iterator = hashtable.keys();
        List<String> list = new ArrayList<>();

        String id = (String) iterator.next();

        while (id != null) {
            list.add(id);
            id = (String) iterator.next();
        }
        return list;
    }
}
