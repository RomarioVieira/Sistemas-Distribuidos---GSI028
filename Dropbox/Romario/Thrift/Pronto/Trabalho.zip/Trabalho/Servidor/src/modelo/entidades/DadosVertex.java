/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;

/**
 *
 * @author dcosta
 */
public class DadosVertex implements Serializable {

    private final String nome;
    private final int idVertex;
    private final String cor;
    private final String descricao;
    private final double peso;
    private int idEdge1;
    private int idEdge2;

    public void setVersion(int version) {
        this.version = version;
    }
    private int version;

    @Override
    public String toString() {
        return "DadosVertex{" + "nameVertex=" + nome + ", idVertex=" + idVertex + ", color=" + cor + ", description=" + descricao + ", weight=" + peso + ", idEdge1=" + idEdge1 + ", idEdge2=" + idEdge2 + ", version=" + version + '}';
    }

    public DadosVertex(String nameVertex, int idVertex, String color, String description, double weight, int version) {
        this.nome = nameVertex;
        this.idVertex = idVertex;
        this.cor = color;
        this.descricao = description;
        this.peso = weight;
        this.version = version;
    }

    public int getVersion() {
        return version;
    }

    public String getColor() {
        return cor;
    }

    public String getDescription() {
        return descricao;
    }

    public double getWeight() {
        return peso;
    }

    public int getIdEdge1() {
        return idEdge1;
    }

    public int getIdEdge2() {
        return idEdge2;
    }

    public void setIdEdge1(int idEdge1) {
        this.idEdge1 = idEdge1;
    }

    public void setIdEdge2(int idEdge2) {
        this.idEdge2 = idEdge2;
    }

    public String getNameVertex() {
        return nome;
    }

    public int getIdVertex() {
        return idVertex;
    }
}
