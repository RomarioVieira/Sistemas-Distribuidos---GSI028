package modelo.entidades;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.Serializable;


public class DadosEdge implements Serializable {

    private final String nome;
    private final int idEdge;
    private final double weight;
    private final String descricao;
    private final boolean direcionado;
    private final int idVertex1;
    private final int idVertex2;
    private final int versao;

    public DadosEdge(String nameEdge, int idEdge, double weight, String description, boolean flagDirected, int idVertex1, int idVertex2, int versao) {
        this.nome = nameEdge;
        this.idEdge = idEdge;
        this.weight = weight;
        this.descricao = description;
        this.direcionado = flagDirected;
        this.idVertex1 = idVertex1;
        this.idVertex2 = idVertex2;
        this.versao = versao;
    }

    /*@Override
    public String toString() {
        return "DadosEdge{" + "nameEdge=" + nome + ", idEdge=" + idEdge + ", weight=" + weight + ", description=" + descricao + ", flagDirected=" + flagDirected + ", idVertex1=" + idVertex1 + ", idVertex2=" + idVertex2 + ", versao=" + versao + '}';
    }*/

    public int getIdVertex1() {
        return idVertex1;
    }

    public int getIdVertex2() {
        return idVertex2;
    }

    public String getNameEdge() {
        return nome;
    }

    public int getIdEdge() {
        return idEdge;
    }

    public int getVersion() {
        return versao;
    }

}
